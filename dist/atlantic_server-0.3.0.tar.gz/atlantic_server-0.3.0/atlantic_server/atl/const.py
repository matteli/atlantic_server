PROGRESS_CHOICES = (("O", "Open"), ("F", "Fixed"), ("C", "Checked"))

NATURE_CHOICES = (("D", "Damage"), ("W", "Work"), ("O", "Other"))
