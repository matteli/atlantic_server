# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['atlantic_server', 'atlantic_server.atl', 'atlantic_server.atl.migrations']

package_data = \
{'': ['*']}

install_requires = \
['Django>=2.2.6,<3.0.0',
 'django-filter>=2.2.0,<3.0.0',
 'djangorestframework>=3.10.3,<4.0.0',
 'drf-nested-routers>=0.91,<0.92']

setup_kwargs = {
    'name': 'atlantic-server',
    'version': '0.3.0',
    'description': 'Server side of an application of an Aircraft Technical Log',
    'long_description': 'Atlantic\n========\n\n',
    'author': 'Matthieu Nué',
    'author_email': 'matthieu.nue@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
